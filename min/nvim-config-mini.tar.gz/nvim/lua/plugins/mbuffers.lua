return {
	"tkachenkosi/mbuffers.nvim",
	config = function()
			require("mbuffers").setup({
				width_win = 0,
			})
	end,
}
