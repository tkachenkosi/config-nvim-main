return {
  'windwp/nvim-autopairs',
  event = "InsertEnter",
  config = true
  -- use opts = {} for passing setup options
  -- this is equivalent to setup({}) function
}
-- автоматизурует работу со скобками
-- настроен без первоначальной загрузки require("nvim-autopairs").setup {}
