-- Base Config
require("core.configs")
require("core.mappings")
require("core.lazy")
require("core.cmds")
-- require("my.myfunc")


